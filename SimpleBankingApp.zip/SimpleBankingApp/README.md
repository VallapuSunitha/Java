# Simple Java Banking Application

A console-based banking system in Java that supports:

- Account creation
- Deposits
- Withdrawals
- Balance checks

## 🚀 Features

- Unique Account ID generation
- Simple and intuitive menu system
- Uses ArrayList to store account data
- Error handling for invalid inputs and insufficient funds

## 🛠 How to Run

1. **Compile the program**:
   ```bash
   javac BankingApp.java
   ```

2. **Run the application**:
   ```bash
   java BankingApp
   ```

## 💻 Example Menu

```
--- Simple Banking App ---
1. Create Account
2. Deposit
3. Withdraw
4. Check Balance
5. Exit
```

## 📄 License

Open source under the MIT License.