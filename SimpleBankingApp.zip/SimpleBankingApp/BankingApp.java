import java.util.ArrayList;
import java.util.Scanner;

class Account {
    private static int nextId = 1001;
    private int accountId;
    private String accountHolder;
    private double balance;

    public Account(String accountHolder) {
        this.accountHolder = accountHolder;
        this.accountId = nextId++;
        this.balance = 0.0;
    }

    public int getAccountId() {
        return accountId;
    }

    public String getAccountHolder() {
        return accountHolder;
    }

    public double getBalance() {
        return balance;
    }

    public void deposit(double amount) {
        if (amount > 0)
            balance += amount;
    }

    public boolean withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            return true;
        }
        return false;
    }
}

public class BankingApp {
    static ArrayList<Account> accounts = new ArrayList<>();
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int choice;
        do {
            System.out.println("\n--- Simple Banking App ---");
            System.out.println("1. Create Account");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Check Balance");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            while (!scanner.hasNextInt()) {
                System.out.print("Invalid input! Enter a number between 1-5: ");
                scanner.next();
            }

            choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1 -> createAccount();
                case 2 -> deposit();
                case 3 -> withdraw();
                case 4 -> checkBalance();
                case 5 -> System.out.println("Thank you for using the banking app!");
                default -> System.out.println("Invalid choice. Try again.");
            }

        } while (choice != 5);
    }

    static void createAccount() {
        System.out.print("Enter account holder's name: ");
        String name = scanner.nextLine();
        Account newAccount = new Account(name);
        accounts.add(newAccount);
        System.out.println("Account created successfully. Account ID: " + newAccount.getAccountId());
    }

    static Account findAccount(int accountId) {
        for (Account acc : accounts) {
            if (acc.getAccountId() == accountId) {
                return acc;
            }
        }
        return null;
    }

    static void deposit() {
        System.out.print("Enter account ID: ");
        int accId = scanner.nextInt();
        System.out.print("Enter amount to deposit: ");
        double amount = scanner.nextDouble();

        Account acc = findAccount(accId);
        if (acc != null) {
            acc.deposit(amount);
            System.out.println("Deposit successful. New balance: " + acc.getBalance());
        } else {
            System.out.println("Account not found.");
        }
    }

    static void withdraw() {
        System.out.print("Enter account ID: ");
        int accId = scanner.nextInt();
        System.out.print("Enter amount to withdraw: ");
        double amount = scanner.nextDouble();

        Account acc = findAccount(accId);
        if (acc != null) {
            if (acc.withdraw(amount)) {
                System.out.println("Withdrawal successful. New balance: " + acc.getBalance());
            } else {
                System.out.println("Insufficient balance or invalid amount.");
            }
        } else {
            System.out.println("Account not found.");
        }
    }

    static void checkBalance() {
        System.out.print("Enter account ID: ");
        int accId = scanner.nextInt();

        Account acc = findAccount(accId);
        if (acc != null) {
            System.out.println("Account Holder: " + acc.getAccountHolder());
            System.out.println("Balance: " + acc.getBalance());
        } else {
            System.out.println("Account not found.");
        }
    }
}