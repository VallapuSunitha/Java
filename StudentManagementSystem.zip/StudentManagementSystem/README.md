# Java Student Management System

A simple console-based Java program that allows users to:

- Add new students
- View all students
- Search students by ID
- Delete students by ID

## 🚀 Features

- Uses ArrayList for dynamic student management
- Menu-driven interaction
- Input validation and error handling

## 🛠 How to Run

1. **Compile the program**:
   ```bash
   javac StudentManagementSystem.java
   ```

2. **Run the application**:
   ```bash
   java StudentManagementSystem
   ```

## 📄 License

Open source under the MIT License.