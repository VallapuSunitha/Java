# Simple Java Calculator

A console-based Java application that performs basic arithmetic operations: addition, subtraction, multiplication, and division.

## 🚀 Features

- User-friendly console interface
- Handles invalid (non-numeric) input
- Supports four basic operations: `+`, `-`, `*`, `/`
- Graceful handling of division by zero

## 📦 Requirements

- Java Development Kit (JDK) 8 or higher
- A terminal or command prompt

## 🛠️ How to Run

1. **Clone the repository**:
   ```bash
   git clone https://github.com/your-username/SimpleJavaCalculator.git
   cd SimpleJavaCalculator
   ```

2. **Compile the program**:
   ```bash
   javac SimpleCalculator.java
   ```

3. **Run the calculator**:
   ```bash
   java SimpleCalculator
   ```

## 💻 Example

```
Enter the first number: 12
Enter the second number: 4
Enter operation (+, -, *, /): /
Result: 3.0
```

## ⚠️ Error Handling

- Prompts user again for invalid numeric inputs
- Handles invalid operation symbols
- Prevents division by zero

## 📁 Project Structure

```
SimpleJavaCalculator/
├── SimpleCalculator.java
└── README.md
```

## 📄 License

This project is open source and available under the MIT License.